<!DOCTYPE html>
<html>
<head>
	<title>
		Teacher's Home
	</title>
<link rel="stylesheet" type="text/css" href="exam.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' >
</head>

<body>

  <span class="label userinfo">Fariha Zohra Prapty</span>
	<img class="img i1"src="added_img\u4.jpg" alt="logged in as:" style="width:55px;height:55px;">
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<div>
		<h1>Student Result Management</h1>
	</div>

	<div>
		<i class="fas fa-user-tie  ic1"></i>
		<i class="fas fa-trophy    ic2"></i>
		<i class="fa fa-users ic3" aria-hidden="true"></i>
		<i class='fas fa-book-open ic4' ></i>
		<i class="fas fa-clipboard ic5"></i>
	</div>

	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<p>
	<a class="p5" href="T_profile.php">Profile</a>
	<a class="p6" href="T_result.php">Result</a>
	<a class="p7" href="T_attendance.php">Attendance</a>
	<a class="p8" href="T_exam.php">Exams</a>
	<a class="p9" href="T_input.php">Marks Entry</a>
    </p>
	<br>
	<br>

</body>
</html>