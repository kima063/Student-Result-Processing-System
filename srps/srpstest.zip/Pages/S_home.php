
<!DOCTYPE html>
<html>
<head>
	<title>
		Student's home
	</title>
<link rel="stylesheet" type="text/css" href="exam.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' >
</head>

<body>

  <span class="label userinfo">Fariha Zohra Prapty</span>
	<img class="img i1"src="added_img\u1.jpg" alt="logged in as:" style="width:55px;height:55px;">
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<div>
		<h1>Student Result Management</h1>
	</div>

	<div>
		<i class="fas fa-user-tie  ic1"></i>
		<i class="fas fa-user-edit ic2"></i>
	</div>

	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<p>
	<a class="ps1" href="S_profile.php">Profile</a>
	<a class="ps2" href="S_academic_record.php">Academic Record</a>
	</p>
	<br><br>

</body>
</html>