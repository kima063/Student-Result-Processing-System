<!DOCTYPE html>
<html>
<head>
	<title>
		Admin's Home
	</title>
<link rel="stylesheet" type="text/css" href="exam.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' >
</head>

<body>

  <span class="label userinfo">Fariha Zohra Prapty</span>
	<img class="img i1"src="added_img\u3.jpg" alt="logged in as:" style="width:55px;height:55px;">
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<div>
		<h1>Student Result Management</h1>
	</div>

	<div>
		<i class="fas fa-user-tie  ic1"></i>
		<i class="far fa-address-card ic2"></i>
		<i class="fas fa-address-card ic3"></i>
		<i class='fas fa-laptop ic4'></i>
	</div>

	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<p>
	<a class="p5" href="A_profile.php">Profile</a>
	<a class="p10" href="A_add_student.php">Add Student</a>
	<a class="p11" href="A_add_teacher.php">Add Teacher</a>
	<a class="p12" href="A_course_offer.php">Course Offer</a>
    </p>
	<br>
	<br>

</body>
</html>


