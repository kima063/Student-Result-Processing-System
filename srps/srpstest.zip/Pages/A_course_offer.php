<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Admin_course_offer.css">
</head>
<body>
<h1>Course Offer</h1>
<br><br><br>
<div class="border" style="border-color: black;border-style: solid;margin-right: 30%;margin-left: 10%;margin-bottom: 15%;">
<p class="cate">Select Category:</p>

<select class="ct">
 
  <option>Teacher</option>
  <option>Student</option>
  
</select>
<br><br><br>
<p class="name">Name:</p>
<br>
<p class="course">Courses:</p>
<select class="s">
  <option>Linear Algebra</option>
  <option>Linear Algebra</option>
  <option>Structured Programming</option>
  
</select>
<br><br><br>
</div>

  
</body>
</html>