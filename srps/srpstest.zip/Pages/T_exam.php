<!DOCTYPE html>
<html>
<head>
	<title>Exams</title>
<link rel="stylesheet" type="text/css" href="exam.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' >
</head>

<body>

  <span class="label userinfo">Fariha Zohra Prapty</span>
	<img class="img i1"src="added_img\u3.jpg" alt="logged in as:" style="width:55px;height:55px;">
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<div>
		<h1>Exam</h1>
	</div>

	<div>
		<i class='fas fa-book-open ic1'></i>
		<i class='fas fa-book-open ic2'></i>
		<i class='fas fa-book-open ic3' ></i>	
	</div>

	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<p><a class="p1" href="T_quiz.php">Quiz</a>
	<a class="p2" href="T_mid.php">Mid</a>
	<a class="p3" href="T_semfinal.php">Semester Final</a></p>
	<br><br>

</body>
</html>